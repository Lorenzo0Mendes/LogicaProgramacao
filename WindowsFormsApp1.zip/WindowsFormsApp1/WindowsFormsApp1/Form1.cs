﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int valor1;
            int valor2;
            int resultado;
            valor1 = int.Parse(txtVelocidade.Text);
            valor2 = int.Parse(txtKm.Text);
            resultado = valor1 * valor2;
            lblResultado.Text = resultado.ToString();
        }
    }
}
