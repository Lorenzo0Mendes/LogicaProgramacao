﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoRandom
{
    public partial class Projeto2 : Form
    {
        public Projeto2()
        {
            InitializeComponent();
        }

        private void Projeto2_Load(object sender, EventArgs e)
        {

        }
    }
}
